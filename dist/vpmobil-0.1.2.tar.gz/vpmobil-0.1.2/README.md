<h1 align="center">vpmobil-py</h1>
<p align="center">
  <a href="https://pypi.org/project/vpmobil/"><img alt="PyPI - Downloads" src="https://img.shields.io/pypi/dm/vpmobil?style=for-the-badge&logo=pypi&logoColor=white&label=Downloads&color=5865F2"></a>
  <a href="#"><img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/annhilati/vpmobil-py?style=for-the-badge&logo=github&label=Letzter%20Commit&color=23A55A"></a>
  <a href="#"><img alt="GitHub License" src="https://img.shields.io/github/license/annhilati/vpmobil-py?style=for-the-badge&label=Lizenz&color=F23F42"></a>

  <p align="center">Because Indiware only distributes substitution plan modules in Germany and the vast majority of users are therefore German, the package and the wiki are formulated in German</p>
</p>

<h3 align="center">────────────────── DISCLAIMER ──────────────────</h3>
<p align="center">
  Das Paket und seine zugehörigen Dienste und Projekte sind eigenständig und stehen in keiner Verbindung zu Indiware, der VpMobil24 App oder stundenplan24.de. Die Nutzung obliegt der Verantwortung des Nutzers. Die   Entwickler übernimmt keine Haftung für Schäden, die durch die Nutzung der App entstehen.
</p>
